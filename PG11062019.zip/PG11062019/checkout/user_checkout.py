# import tornado.ioloop
import tornado.web
import os

print("sdrthrthjhrthrtjhrtjtyjtyjtyjwjrtjhrtjhrtjh654jrt4654j6tyj4ty6j4ty")

class Checkout(tornado.web.RequestHandler):
    def post(self):
        mrc = self.get_argument("mrc")
        amount = self.get_argument("amount")
        currency = self.get_argument("currency")
        redirectUrl = self.get_argument("redirectUrl")

        self.render("checkout_amalpay.html",amount=amount,currency=currency,mrc=mrc,redirectUrl=redirectUrl)

# settings = dict(
#         static_path=os.path.join(os.path.dirname(__file__), "static")
#     )
# def make_app():
#     return tornado.web.Application([
#         (r"/checkout", Checkout),
#         (r"/(.*)", tornado.web.StaticFileHandler,
#          dict(path=settings['static_path']))
#     ],**settings)

# if __name__ == "__main__":
#     app = make_app()
#     app.listen(8888)
#     tornado.ioloop.IOLoop.current().start()