// JavaScript Document 
console.log("guhyoijftyuio");
function checkCard(){
    var cNumber=document.getElementById("cNumber")
    
   
    
    if (cNumber.value.length!=16) {
        console.log("if callesgfsdgsdcdd");
        
        cNumber.setCustomValidity("Please Enter Right Card Number")
        cNumber.valid=false;
      }
      else{console.log("else called");
      cNumber.setCustomValidity("")
          cNumber.valid=true;
      }
    
}
function checkCVC(){
    var cNumber=document.getElementById("cvc")
    
    if ((cNumber.value.length!=3)) {
        console.log("if callesgfsdgsdcdd");
        
        cNumber.setCustomValidity("Please Enter Right CVC Number")
      }
      else{console.log("else called");
      cNumber.setCustomValidity("")
          cNumber.valid=true;
      }
    
}
function checkExp(){
    var cNumber=document.getElementById("exp")
    console.log("data",cNumber.value.split("/"));
    
    if(cNumber.value.split("/")[0]>12)
     {
        cNumber.setCustomValidity("Please Enter Right CVC Number") 
        return;
     }
    if ((cNumber.value.length!=5)) {
        console.log("if callesgfsdgsdcdd");
        
        cNumber.setCustomValidity("Please Enter Right CVC Number")
      }
      else{console.log("else called");
      cNumber.setCustomValidity("")
          cNumber.valid=true;
      }
}

function callApi(){
   
    
    console.log("fuction called");
    
   var email= document.getElementById("email").value;
   var cardNo= document.getElementById("cNumber").value;
   var exp= document.getElementById("exp").value;
   var res = exp.split("/");
   var cvc= document.getElementById("cvc").value;
   var m_id= document.getElementById("m_id").value;
   var currency= document.getElementById("currency").value;
    var amount= document.getElementById("amount").value;
    var captured= document.getElementById("captured").checked;
    console.log("captured",captured);
    
   console.log("input fielsd",email,cardNo,exp,cvc);
   const userdata = {
    m_id:m_id,
    email:email,
    number:cardNo,
    expMonth:res[0],
    expYear:res[1],
    cvc:122,
   // cardholderName:"prem chand",
    amount:amount,
    currency:currency,
    captured:captured?1:0
   }


   const data  = Object.keys(userdata).map((key) => {
    return encodeURIComponent(key) + '=' + encodeURIComponent(userdata[key]);
  }).join('&');

//  var requestOptions = {
//    method: "POST",
//    url: "http://139.59.66.127:8890/merchant/api/v1/widget",
//
//    data: data,
//    headers:{
//        "Content-Type" :"*",
//        'Access-Control-Allow-Origin':"*",
//        'Access-Control-Allow-Methods':'GET, PUT, POST, DELETE, HEAD, OPTIONS'
//    }
//  };
//
//   axios(requestOptions).then(console.log("api called")).catch(console.log("dfsdfa"));

var http = new XMLHttpRequest();
var url = 'http://139.59.66.127:8890/merchant/api/v1/widget';
var params = '';
http.open('POST', url, true);

//Send the proper header information along with the request
http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

http.onreadystatechange = function() {//Call a function when the state changes.
    if(http.readyState == 4 && http.status == 200) {
     let res= JSON.parse(http.responseText);
     console.log("response",res);
     if(res.status==="success"){
        document.getElementById("loader").style.display=""
        document.getElementById("status").value=res.status;
        document.getElementById("charge_id").value=res.data.charge_id;
        document.getElementById("redirectUrlForm").submit()
     }
       
      
    }
}
http.send(data);



   return false;
}
function checkDate(){
    var exp= document.getElementById("exp").value;
    console.log(exp.length);
    if(exp.length==2)
     {
        document.getElementById("exp").value=`${exp}/`;
     }
     return;
}