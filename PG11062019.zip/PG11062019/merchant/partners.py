import tornado.web
import tornado
import tornado.ioloop
import pyaes
import time
import uuid
import pymysql
import json
from remove_tags import *
from auth import *
from cross_origin import *
from db import *

import hashlib




@jwtauth
class partner_request(BaseHandler):

    def post(self):
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))
        partner_id = remove_tag(self.get_argument('partner_id'))

        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id=m_id
                user_id=token_decode['userid']
            else:
                pass

        if merchant_id:
            if merchant_id==partner_id:
                response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "You cannot send yourself a request",}
                raise tornado.web.Finish(response)
                
            connection, cursor = db_connect()
            select_role='SELECT Role FROM merchant_account WHERE username=cast(%s as char) AND merchant_id=cast(%s as char)'
            cursor.execute(select_role, (user_id,merchant_id))
            Role_check = cursor.fetchall()
            ##print(Role_check[0][0])
            alwd_role=['owner']
            if Role_check[0][0] in alwd_role:
                pass
            else:
                response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "Permission Denied",}
                raise tornado.web.Finish(response)
            created = time.time()
            select_query = "SELECT partner1, partner2 FROM partners WHERE partner1 = cast(%s as char) AND partner2 = cast(%s as char)"
            cursor.execute(select_query, (merchant_id,partner_id))
            requestCheck = cursor.fetchall()
            cursor.execute(select_query, (partner_id,merchant_id))
            requestCheck1 = cursor.fetchall()
            if requestCheck1 or requestCheck:
                response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "Request already exists",}
                raise tornado.web.Finish(response)
            else:
                select_query = "SELECT account_name , username FROM merchant_account WHERE merchant_id = cast(%s as char) AND Role = 'owner'"
                cursor.execute(select_query, (merchant_id))
                sender = cursor.fetchall()  

                select_query = "SELECT email FROM merchant WHERE username = cast(%s as char) "
                cursor.execute(select_query, (sender[0][1]))
                sender_email = cursor.fetchall()

                select_query = "SELECT account_name , username FROM merchant_account WHERE merchant_id = cast(%s as char) AND Role = 'owner'"
                cursor.execute(select_query, (partner_id))
                reciever = cursor.fetchall()
                if not reciever:
                    response = {
                    "status": "error",
                    "code": 400,
                    "data": "null",
                    "message": "Partner doesn't exist",
                    }

                    raise tornado.web.Finish(response)

                select_query = "SELECT email FROM merchant WHERE username = cast(%s as char) "
                cursor.execute(select_query, (reciever[0][1]))
                reciever_email = cursor.fetchall()
                #print(merchant_id,sender[0][1],sender_email[0][0],partner_id,reciever[0][1],reciever_email[0][0],created,"partner","pending")
            if sender and sender_email and reciever and reciever_email:
                
                insert_query = "INSERT INTO partners (partner1 ,username1 ,email1 ,partner2 ,username2 ,email2, created, objectType, status) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                cursor.execute(insert_query, (merchant_id,sender[0][1],sender_email[0][0],partner_id,reciever[0][1],reciever_email[0][0],float(created),"partner","pending"))
                connection.commit()
                response = {"status": "success","code": 200,
                                "data": '',
                                "message": "Request sent succesfully"}
                self.write(response)
            else:
                response = {
                    "status": "error",
                    "code": 400,
                    "data": "null",
                    "message": "Partner doesn't exist",
                }

                raise tornado.web.Finish(response)
        else:

            response = {
                "status": "error",
                "code": 403,
                "data": "",
                "message": "Access Denied",
            }

            raise tornado.web.Finish(response)


@jwtauth
class partner_response(BaseHandler):

    def post(self):
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))
        partner_id = remove_tag(self.get_argument('partner_id'))
        response = remove_tag(self.get_argument('response'))

        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id=m_id
                user_id=token_decode['userid']
            else:
                pass

        if merchant_id:
            valid_response = ["Accepted","Declined"]
            if response in valid_response:
                pass
            else:
                response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "invalid response",}
                raise tornado.web.Finish(response)
            connection, cursor = db_connect()
            select_role='SELECT Role FROM merchant_account WHERE username=cast(%s as char) AND merchant_id=cast(%s as char)'
            cursor.execute(select_role, (user_id,merchant_id))
            Role_check = cursor.fetchall()
            #print(Role_check[0][0])
            alwd_role=['owner']
            if Role_check[0][0] in alwd_role:
                pass
            else:
                response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "Permission Denied",}
                raise tornado.web.Finish(response)

            select_query = "UPDATE partners SET status = cast(%s as char) WHERE partner2 = cast(%s as char) AND partner1 = cast(%s as char)"
            cursor.execute(select_query,(response ,merchant_id, partner_id))
            connection.commit()
            response = {"status": "success","code": 200,
                                "data": "",
                                "message": f"Request {response} succesfully"}
            self.write(response)
        
        else:

            response = {
                "status": "error",
                "code": 403,
                "data": "",
                "message": "Access Denied",
            }

            raise tornado.web.Finish(response)

                



@jwtauth
class partner(BaseHandler):

    def get(self):
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))
        

        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id=m_id
                user_id=token_decode['userid']
            else:
                pass

        if merchant_id:
            connection, cursor = db_connect()
            select_role='SELECT Role FROM merchant_account WHERE username=cast(%s as char) AND merchant_id=cast(%s as char)'
            cursor.execute(select_role, (user_id,merchant_id))
            Role_check = cursor.fetchall()
            #print(Role_check[0][0])
            alwd_role=['owner']
            if Role_check[0][0] in alwd_role:
                pass
            else:
                response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "Permission Denied",}
                raise tornado.web.Finish(response)
            
            select_query = "SELECT * FROM partners WHERE partner1 = cast(%s as char)"
            cursor.execute(select_query, (merchant_id))
            partner_list = cursor.fetchall()
            select_lenght = "SELECT COUNT(*) FROM partners WHERE partner1 = cast(%s as char)"
            cursor.execute(select_lenght, (merchant_id))
            data_length=cursor.fetchall()

            
            results = [] 
            for i in range(len(partner_list)):
                result = {"partner":partner_list[i][3],
                          "username":partner_list[i][4],
                          "created":str(partner_list[i][6]),
                          "status":partner_list[i][8],
                          "objectType":partner_list[i][7],
                          "Type":"send",}
                results.append(result)
            #print(results,"rrrrrrrrrrrrrrrrr")
            select_query = "SELECT * FROM partners WHERE partner2 = cast(%s as char)"
            cursor.execute(select_query, (merchant_id))
            partner_list = cursor.fetchall()
            select_lenght = "SELECT COUNT(*) FROM partners WHERE partner2 = cast(%s as char)"
            cursor.execute(select_lenght, (merchant_id))
            data_length1=cursor.fetchall()
            for i in range(len(partner_list)):
                result = {"partner":partner_list[i][0],
                          "username":partner_list[i][1],
                          "created":str(partner_list[i][6]),
                          "status":partner_list[i][8],
                          "objectType":partner_list[i][7],
                          "Type":"recieve",}
                results.append(result)
            #print(results,"rrrrrrrrrrrrrrrrr")
            response = {"status": "success","code": 200,
                                "data": results,
                                "data_length":data_length1[0][0]+data_length[0][0],
                                "message": ""}
            self.write(response)
        
        else:

            response = {
                "status": "error",
                "code": 403,
                "data": "",
                "message": "Access Denied",
            }

            raise tornado.web.Finish(response)




@jwtauth
class partner_delete(BaseHandler):

    def post(self):
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))
        partner_id = remove_tag(self.get_argument('partner_id'))

        

        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id=m_id
                user_id=token_decode['userid']
            else:
                pass

        if merchant_id:
            connection, cursor = db_connect()
            select_role='SELECT Role FROM merchant_account WHERE username=cast(%s as char) AND merchant_id=cast(%s as char)'
            cursor.execute(select_role, (user_id,merchant_id))
            Role_check = cursor.fetchall()
            #print(Role_check[0][0])
            alwd_role=['owner']
            if Role_check[0][0] in alwd_role:
                pass
            else:
                response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "Permission Denied",}
                raise tornado.web.Finish(response)
            
            select_query = "SELECT * FROM partners WHERE partner1 = cast(%s as char)"
            cursor.execute(select_query, (merchant_id))
            partner_list = cursor.fetchall()

            sql_delete = "DELETE FROM partners WHERE partner1 = cast(%s as char) AND partner2 = cast(%s as char)"
            # try:
            # print(merchant_id,partner_id)
            cursor.execute(sql_delete, (merchant_id,partner_id))
            connection.commit()
            # except:
            cursor.execute(sql_delete, (partner_id,merchant_id))
            connection.commit()
            response = {"status": "success","code": 200,
                                "data": "",
                                "message": "Partner Deleted succesfully"}
            self.write(response)

            
        else:

            response = {
                "status": "error",
                "code": 403,
                "data": "",
                "message": "Access Denied",
            }
            raise tornado.web.Finish(response)


@jwtauth
class merchant_partner_filter(BaseHandler):
    def post(self):
        partner_id = remove_tag(self.get_argument('partnerId',False))
        status=remove_tag(self.get_argument('status',False))
        partner_name = remove_tag(self.get_argument('partnerName',False))
        token = self.request.headers.get('Authorization')
        limit=self.get_argument('limit', False)
        m_id = remove_tag(self.get_argument('m_id'))
        time=self.get_argument('time', False)
        pre_time=self.get_argument('pre_time', False)

        if limit ==False:
            limit=10
        else:
            limit=int(limit)
        
        if limit>100:
            limit=100


        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id = m_id
            else:
                pass

        if merchant_id:
            #print(merchant_id,'merchant_id')
            connection, cursor = db_connect()
            count_query=f"SELECT count(*) FROM partners WHERE created<{time}"
            query = f"SELECT * FROM partners WHERE created<{time}"
            if pre_time:
                query = f"SELECT * FROM partners WHERE created>{pre_time}"
            
            if partner_id:
                if query[-5:] == "WHERE":
                    add = f" (partner2 = '{partner_id}' AND partner1 = '{merchant_id}')"
                    
                else:
                    add = f" AND (partner2 = '{partner_id}' AND partner1 = '{merchant_id}')"

                query = query + add
                count_query=count_query+add
            
            if partner_id:
                if query[-5:] == "WHERE":
                    add = f" OR(partner1= '{partner_id}' AND partner2 = '{merchant_id}')"
                    
                else:
                    add = f" OR( partner1 = '{partner_id}'  AND partner2 = '{merchant_id}')"

                query = query + add
                count_query=count_query+add

            if status:
                if query[-5:] == "WHERE":
                    add = f" status = '{status}'"
                else:
                    add = f" AND status = '{status}'"
            
                query = query + add
                count_query=count_query+add


        
            if partner_name:
                if query[-5:] == "WHERE":
                    add = f" username2 = '{partner_name}' AND partner1 = '{merchant_id}'"
                    
                else:
                    add = f" AND username2 = '{partner_name}' AND partner1 = '{merchant_id}'"

                query = query + add
                count_query=count_query+add
            
            if partner_name:
                if query[-5:] == "WHERE":
                    add = f" OR(username1= '{partner_name}' AND partner2 = '{merchant_id}')"
                    
                else:
                    add = f" OR( username1 = '{partner_name}'  AND partner2 = '{merchant_id}')"

                query = query + add
                count_query=count_query+add

            if time:
                    if query[-5:] == "WHERE":
                        add = f" partner1 = '{merchant_id}' ORDER BY created DESC LIMIT {limit}"
                        cadd = f" partner1 = '{merchant_id}'"

                    else:
                        add = f" AND partner1 = '{merchant_id}' ORDER BY created DESC LIMIT {limit}"
                        cadd = f" AND partner1 = '{merchant_id}'"
            if pre_time:
                if query[-5:] == "WHERE":
                    add = f" partner1 = '{merchant_id}' ORDER BY created ASC LIMIT {limit}"
                    cadd = f" partner1  = '{merchant_id}'"

                else:
                    add = f" AND partner1 = '{merchant_id}' ORDER BY created ASC LIMIT {limit}"
                    cadd = f" AND partner1 = '{merchant_id}'"
            query = query + add
            count_query=count_query+cadd
            cursor.execute(count_query)
            count = cursor.fetchall()
            #print("queryyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy",query)
            cursor.execute(query)
            records = cursor.fetchall()

            if records:
                results=[]
                for i in range(len(records)):
                    result = {"partner":records[i][0],
                          "username":records[i][1],
                          "created":str(records[i][6]),
                          "status":records[i][8],
                          "objectType":records[i][7],
                         }
                    results.append(result)
                if pre_time:
                    results=results[::-1]
                response ={
                    "status": "success",
                    "code": 200,
                    "data":results,
                    "data_length":count[0][0],
                    "message": "",}
                self.write(response)
            else:
                response = {
                    "status": "error",
                    "code": 404,
                    "data": "",
                    "message": "data not available",
                }
                raise tornado.web.Finish(response)
        else:
            response = {
                "status": "error",
                "code": 404,
                "data": "",
                "message": "Permission Denied",
            }
            raise tornado.web.Finish(response)

        