import tornado.web
import tornado
import tornado.ioloop
import time
import time
import uuid
import pymysql
import pyaes
import json
import hashlib
from remove_tags import *
from auth import *
from cross_origin import *
import time
from db import *
from cc_brand import *

class BaseHandler1(tornado.web.RequestHandler):

    def set_default_headers(self):
        #print("setting headers!!!")
        self.set_header("Access-Control-Allow-Origin", "*")
        # self.add_header('Access-Control-Allow-Origin', self.request.headers.get('Origin', '*'))
        self.set_header('Access-Control-Allow-Methods', 'POST, GET')
        # self.add_header('Access-Control-Request-Method', 'GET')
        self.set_header('Access-Control-Allow-Headers', 'Content-Type')
        # self.add_header('Access-Control-Allow-Headers', 'X-Requested-With')
        self.set_header("Access-Control-Allow-Credentials", "false")
        # self.set_header('Access-Control-Max-Age', '86400')

        self.set_header("Access-Control-Allow-Headers", "browser,ipaddress,platform,x-requested-with,access-control-allow-origin,X-PINGOTHER,authorization")
        #print("set headers!!!")

    def post(self):
        self.write('some post')

    def get(self):
        self.write('some get')
class widget(BaseHandler1):
    def post(self):
        merchant_id = remove_tag(self.get_argument('m_id'))
        email=self.get_argument("email")
        # customerId = regex(remove_tag(self.get_argument('customerId')))
        number = remove_tag(self.get_argument('number'))
        exp_month = remove_tag(self.get_argument('expMonth'))
        exp_year = remove_tag(self.get_argument('expYear'))
        cvc = remove_tag(self.get_argument('cvc'))
        # cardholdername = remove_tag(self.get_argument('cardholderName'))
        amount = remove_tag(self.get_argument('amount'))
        currency = remove_tag(self.get_argument('currency'))
        # card = remove_tag(self.get_argument('card', False))
        captured = remove_tag(self.get_argument('captured', False))


        if merchant_id:
            if  email and number and exp_month and exp_year and cvc  and amount and currency:
                if re.search(r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)", email):
                    connection, cursor = db_connect()
                    sql_select_Query = "SELECT * FROM customers WHERE email=cast(%s as char) AND merchant_id=cast(%s as char)"
                    cursor.execute(sql_select_Query, (email, merchant_id))
                    record = cursor.fetchall()
                    ##print(record)
                    if record == ():
                        customerId = str(uuid.uuid1())
                        Insert_customer = ("INSERT INTO customers(id ,created ,objectType ,email ,merchant_id) VALUES (%s,%s,%s,%s,%s)")
                        cursor.execute(Insert_customer, (customerId,time.time(),"customer",email,merchant_id))
                        connection.commit()
                    else:
                        customerId = record[0][0]
                    fingereprint = hashlib.sha224(number.encode()).hexdigest()
                    brand = cc_brand(number)
                    card_id= "card_" + str(uuid.uuid1())
                    Insert_card = ("INSERT INTO cards(card_id ,created,objectType ,first6,last4 ,fingerprint ,expMonth ,expYear,cardholderName ,customerId ,brand ,email,merchant_id) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)")
                    cursor.execute(Insert_card,(card_id,time.time(),"card"
                                        , int(number[:6]), int(number[-4:]),fingereprint
                                        , int(exp_month), int(exp_year),
                                        ""
                                        , str(customerId)
                                        , str(brand),email,merchant_id))
                    connection.commit()
                    charge_id = str(uuid.uuid1())

                    Insert_charge = ("INSERT INTO charge(id ,created ,objectType ,amount ,currency ,card_id ,captured ,merchant_id) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)")

                    cursor.execute(Insert_charge,(str(charge_id),float(time.time()), "charge", float(amount),str(currency),str(card_id),1,merchant_id))
                    connection.commit()

                    type_event = "CHARGE_CREATED"
                    id = "event_" + str(uuid.uuid1())
                    data = "char_" + str(uuid.uuid1())
                    log = "log_" + str(uuid.uuid1())
                    created = time.time()

                    url = "/merchant/api/v1/widget"
                    platform = self.request.headers.get('platform')
                    ipaddress = self.request.headers.get('ipaddress')

                    request_body= {"email":email,"currency":currency,"customerId":customerId,
                    "number":number,"exp_month":exp_month,"exp_year":exp_year,"cvc":cvc}

                    Insert_log = (
                        "INSERT INTO log(log ,created ,method ,url ,status ,ip_address, source, request_body, response_body,merchant_id) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)")
                    cursor.execute(Insert_log, (str(log), float(created), "post ", url, int(200), str(ipaddress), str(platform), str(request_body), "",merchant_id))

                    Insert_event = (
                        "INSERT INTO event(event_id ,created ,objectType ,type ,data ,log ,com_id,customer_id, merchant_id) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)")
                    cursor.execute(Insert_event, (id, float(created), "event", type_event, data, log,charge_id,customerId,merchant_id))

                    Insert_data = (
                        "INSERT INTO data(data_id ,created ,objectType ,amount ,currency  ,card ,captured,merchant_id ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)")
                    cursor.execute(Insert_data, (data, float(created), "charge create", float(amount), currency ,card_id, int(captured),merchant_id))
                    connection.commit()

                    type_event = "CUSTOMER_CREATE"
                    id = "event_" + str(uuid.uuid1())
                    data = "char_" + str(uuid.uuid1())
                    log = "log_" + str(uuid.uuid1())
                    created = time.time()

                    url = "/merchant/api/v1/widget"
                    platform = self.request.headers.get('platform')
                    ipaddress = self.request.headers.get('ipaddress')

                    request_body= {"email":email,"currency":currency,"customerId":customerId,
                    "number":number,"exp_month":exp_month,"exp_year":exp_year,"cvc":cvc}

                    Insert_log = (
                        "INSERT INTO log(log ,created ,method ,url ,status ,ip_address, source, request_body, response_body,merchant_id) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)")
                    cursor.execute(Insert_log, (str(log), float(created), "post ", url, int(200), str(ipaddress), str(platform), str(request_body), "",merchant_id))

                    Insert_event = (
                        "INSERT INTO event(event_id ,created ,objectType ,type ,data ,log ,com_id,customer_id, merchant_id) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)")
                    cursor.execute(Insert_event, (id, float(created), "event", type_event, data, log,customerId,customerId,merchant_id))

                    Insert_data = (
                        "INSERT INTO data(data_id ,created ,objectType ,amount ,currency  ,card ,captured  ,merchant_id ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)")
                    cursor.execute(Insert_data, (data, float(created), "customer create", float(amount), currency,card_id, int(captured),merchant_id))
                    connection.commit()



                    type_event = "CARD_CREATE"
                    id = "event_" + str(uuid.uuid1())
                    data = "char_" + str(uuid.uuid1())
                    log = "log_" + str(uuid.uuid1())
                    created = time.time()

                    url = "/merchant/api/v1/widget"
                    platform = self.request.headers.get('platform')
                    ipaddress = self.request.headers.get('ipaddress')

                    request_body= {"email":email,"currency":currency,"customerId":customerId,
                    "number":number,"exp_month":exp_month,"exp_year":exp_year,"cvc":cvc}

                    Insert_log = (
                        "INSERT INTO log(log ,created ,method ,url ,status ,ip_address, source, request_body, response_body,merchant_id) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)")
                    cursor.execute(Insert_log, (str(log), float(created), "post ", url, int(200), str(ipaddress), str(platform), str(request_body), "",merchant_id))

                    Insert_event = (
                        "INSERT INTO event(event_id ,created ,objectType ,type ,data ,log ,com_id,customer_id, merchant_id) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)")
                    cursor.execute(Insert_event, (id, float(created), "event", type_event, data, log,card_id,customerId,merchant_id))

                    Insert_data = (
                        "INSERT INTO data(data_id ,created ,objectType ,amount ,currency  ,card ,captured ,merchant_id ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)")
                    cursor.execute(Insert_data, (data, float(created), "card create", float(amount), currency,card_id, int(captured),merchant_id))
                    connection.commit()


                    # result1 = {"customer":{
                    #                 "id": customerId,
                    #                 "email":email,
                    #                 "created":time.time(),
                    #                 "objectType": "customer",
                    #                 "merchant_id":merchant_id,
                    #           "card":{
                    #                 "email": email,
                    #                 "created":time.time(),
                    #                 "objectType": "cards",
                    #                 "card_id":card_id,
                    #                 "first6":number[:6],
                    #                 "last4":number[-4:],
                    #                 "fingerprint":fingereprint,
                    #                 "expMonth":exp_month,
                    #                 "expYear":exp_year,
                    #                 "cardholdername":cardholdername,
                    #                 "brand":brand,
                    #                 "merchant_id":merchant_id,
                    #             "charge":{
                    #                 "charge_id":charge_id,
                    #                 "objectType": "charge",
                    #                 "created":time.time(),
                    #                 "amount":amount,
                    #                 "currency":currency,}}}}
                    result1={"charge_id":charge_id}

                    response={"status": "success","code": 200,
                        "data": result1,
                        "message": "payment done successfully"}
                    self.write(response)

                else:
                    response = {
                        "status": "error",
                        "code": 404,
                        "data": "null",
                        "message": "Wrong email Given",
                    }
                    raise tornado.web.Finish(response)
            else:
                    response = {
                        "status": "error",
                        "code": 404,
                        "data": "null",
                        "message": "something is missing",
                    }
                    raise tornado.web.Finish(response)
        else:
            response = {
                "status": "error",
                "code": 403,
                "data": "",
                "message": "Access Denied",
            }
            raise tornado.web.Finish(response)











