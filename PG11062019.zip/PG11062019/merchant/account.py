import tornado.web
import tornado
import tornado.ioloop
import pyaes
import time
import uuid
import pymysql
import json
from remove_tags import *
from auth import *
from cross_origin import *
from db import *
import auth
import hashlib
import setup
import smtplib

@jwtauth
class new_account(BaseHandler):

    def post(self):

        account_name = remove_tag(self.get_argument('account_name'))
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))
        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            auth.secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        #print("ddddddddddddddddddddd",token_decode)
        for i in range(len(token_decode['mAndR'])):
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id = m_id
                user_id=token_decode['userid']

            else:
                pass

        if merchant_id:
            merchant_id1 = "mrc_" + str(uuid.uuid1())
            public_key = "pk_" + str(uuid.uuid1())
            secret_key = "sk__" + str(uuid.uuid1())

            if account_name:
                connection, cursor = db_connect()
                sql = "INSERT INTO merchant_account (merchant_id,public_key,secret_key,account_name,Role,username) VALUES(%s,%s,%s,%s,%s,%s)"
                cursor.execute(sql, (merchant_id1, public_key, secret_key, account_name,"owner",user_id))
                connection.commit()

                response = {"status": "success", "code": 200,
                            "data": {"username":user_id,"merchant_id":merchant_id1},
                            "message": "account created successfully"}
                self.write(response)

            else:
                response = {
                "status": "error",
                "code": 404,
                "data": "null",
                "message": "provide account name",
                    }
                raise tornado.web.Finish(response)
        else:
            response = {
                    "status": "error",
                    "code": 404,
                    "data": "null",
                    "message": "permission denied",
                        }
            raise tornado.web.Finish(response)



@jwtauth
class user_add(BaseHandler):

    def post(self):

        account_name = remove_tag(self.get_argument('account_name',False))
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))
        Role = remove_tag(self.get_argument('Role'))
        email = remove_tag(self.get_argument('email'))
        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            auth.secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        #print("ddddddddddddddddddddd",token_decode)
        for i in range(len(token_decode['mAndR'])):
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id = m_id
                user_id=token_decode['userid']

            else:
                pass

        if merchant_id:
            created = time.time()
            valid_role = ["administrator","owner","view","editor"]
            connection, cursor = db_connect()
            select_role='SELECT Role FROM merchant_account WHERE username=cast(%s as char) AND merchant_id=cast(%s as char)'
            cursor.execute(select_role, (user_id,merchant_id))
            Role_check = cursor.fetchall()
            #print(Role_check[0][0])
            alwd_role=['owner']
            #print("Role_check[0][0]--------------------------------------------------------",Role_check[0][0])
            if Role_check[0][0] in alwd_role:
                pass
            else:
                response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "Permission Denied..",}
                raise tornado.web.Finish(response)
            select_query = "SELECT * FROM merchant_account WHERE merchant_id=cast(%s as char) AND Role=cast(%s as char)"
            cursor.execute(select_query,(merchant_id,"owner"))
            user_data = cursor.fetchall()
            select_email = "SELECT username FROM merchant WHERE email =cast(%s as char)"
            cursor.execute(select_email,(email))
            username = cursor.fetchall()
            if Role in valid_role:
                if Role in ["administrator","view","editor"]:
                    if user_data:
                        connection, cursor = db_connect()
                        insert_query = "INSERT INTO merchant_account(merchant_id , public_key, secret_key, account_name, Role, username, currency,created,status)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                        cursor.execute(insert_query,(user_data[0][0],user_data[0][1],user_data[0][2],user_data[0][3],Role,username[0][0],user_data[0][6],created ,"pending"))
                        connection.commit()
                        # possible = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
                        # ecode = ''
                        # for i in range(1, 10):
                        #     temp = random.choice(possible)
                        #     ecode = ecode + temp
                        # a = merchantroleurl + "?email={}&ecode={}".format(email, ecode)
                        a = merchantroleurl + "?email={}".format(email)
                        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)

                        server.login(email_host, email_pass)
                        server.sendmail(
                            email_host,
                            email,
                            "Subject:AmalPay account request \n You have requested form merchant {} of the role of {} \n Please click on the link below to accept {}".format(merchant_id,Role,a))
                        server.quit()
                        response = {"status": "success", "code": 200,
                            "data": "",
                            "message": "Request added successfully"}
                        self.write(response)
                    else:
                        response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "user not exist",}
                        raise tornado.web.Finish(response)
                elif Role=='owner':
                    if user_data:
                        connection, cursor = db_connect()
                        update_query="UPDATE merchant_account SET Role='administrator' WHERE Role='owner' AND merchant_id=cast(%s as char)"
                        cursor.execute(update_query,(merchant_id))
                        connection.commit()
                        insert_query = "INSERT INTO merchant_account(merchant_id , public_key, secret_key, account_name, Role, username, currency,created,status)VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                        cursor.execute(insert_query,(user_data[0][0],user_data[0][1],user_data[0][2],user_data[0][3],Role,username[0][0],user_data[0][6],created ,"pending"))
                        connection.commit()
                        a = merchantroleurl + "?email={}".format(email)
                        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)

                        server.login(email_host, email_pass)
                        server.sendmail(
                            email_host,
                            email,
                            "Subject:AmalPay account request \n You have requested form merchant {} of the role of {} \n Please click on the link below to accept {}".format(merchant_id,Role,a))
                        server.quit()
                        response = {"status": "success", "code": 200,
                            "data": "",
                            "message": "Request added successfully"}
                        self.write(response)
                    else:
                        response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "user not exist",}
                        raise tornado.web.Finish(response)
                else:
                        response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "Invalid Role",}
                        raise tornado.web.Finish(response)


            else:
                response = {
                "status": "error",
                "code": 403,
                "data": "",
                "message": "Invalid Role",}
                raise tornado.web.Finish(response)
        else:
                response = {
                "status": "error",
                "code": 403,
                "data": "",
                "message": "Permission denied",}
                raise tornado.web.Finish(response)
                        

                