import tornado.web
import tornado
import tornado.ioloop
import pyaes
import time
import uuid
import pymysql
import json
from remove_tags import *
from auth import *
from cross_origin import *
from db import *
from enc_ import *
import hashlib
import base64



@jwtauth
class merchant_payout(BaseHandler):
    def get(self):
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))

        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id = m_id
                user_id=token_decode['userid']
            else:
                pass

        if merchant_id:
            connection, cursor = db_connect()

            sql_select="SELECT * FROM payout WHERE merchant_id = %s"
            cursor.execute(sql_select,(merchant_id))
            records = cursor.fetchall()
            if records:
                    results = []
                    for i in range(len(records)):
                        result = {
                            "id": records[i][0],
                            "created": str(records[i][1]),
                            "objectType": records[i][2],
                            "amount": str(records[i][3]),
                            "currency": records[i][4],
                            "status": records[i][5],
                            "payout_till": str(records[i][6]),
                            "merchant_id": records[i][7],
                            "fee":  str(records[i][8]),
                        }
                        results.append(result)
                    response = {"status": "success", "code": 200,
                                "data": results,
                                "data_length": len(records),
                                "message": ""}
                    self.write(response)
                    
            else:
                response = {
                    "status": "error",
                    "code": 400,
                    "data": "",
                    "message": "data not available",
                }
                raise tornado.web.Finish(response)
        else:

            response = {
                "status": "error",
                "code": 403,
                "data": "",
                "message": "Access Denied",
            }
            raise tornado.web.Finish(response)



