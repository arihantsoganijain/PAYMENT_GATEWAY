import tornado.web
import tornado
import tornado.ioloop
import pyaes
import time
import uuid
import pymysql
import json
from remove_tags import *
from auth import *
from cross_origin import *
from db import *
import datetime
from datetime import timedelta
import time
import hashlib

import requests

def currency_convertor(currency1,currency2):
   url = "https://min-api.cryptocompare.com/data/price?fsym={}&tsyms={}&api_key=1eecefe16a06396e35c13a5d03dd2ed8c4771dacb5934804bf7931db3ea5092b".format(currency1,currency2)
   r = requests.get(url=url)
   r=eval(r.text)
   return r[currency2]

@jwtauth
class dashboard(BaseHandler):

    def get(self):
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))

        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id = m_id
            else:
                pass

        if merchant_id:
            connection, cursor = db_connect()

            sql_length_query = ("SELECT COUNT(*) FROM customers WHERE merchant_id=cast(%s as char)")
            cursor.execute(sql_length_query, (merchant_id,))
            length = cursor.fetchall()
            len_customer_created = length[0][0]
            #print("len_customer_created", len_customer_created)

            sql_length_query = ("SELECT COUNT(*) FROM charge WHERE merchant_id=cast(%s as char) AND captured=1")
            cursor.execute(sql_length_query, (merchant_id,))
            length = cursor.fetchall()
            len_successfull_payments = length[0][0]
            #print("len_successfull_payments", len_successfull_payments)

            sql_length_query = ("SELECT COUNT(*) FROM charge WHERE merchant_id=cast(%s as char) AND refunded=1")
            cursor.execute(sql_length_query, (merchant_id,))
            length = cursor.fetchall()
            len_chargebacks = length[0][0]
            #print("len_chargebacks", len_chargebacks)

            sql_length_query = ("SELECT COUNT(*) FROM subscription WHERE merchant_id=cast(%s as char) ")
            cursor.execute(sql_length_query, (merchant_id,))
            length = cursor.fetchall()
            len_subscriptions = length[0][0]
            #print("len_subscriptions", len_subscriptions)

            sql_length_query = ("SELECT amount, currency FROM charge WHERE merchant_id=cast(%s as char) AND captured=1")
            cursor.execute(sql_length_query, (merchant_id,))
            amountData = cursor.fetchall()
            sql_length_query = ("SELECT currency FROM merchant_account WHERE merchant_id=cast(%s as char) AND Role='owner'")
            cursor.execute(sql_length_query, (merchant_id,))
            mer_curr = cursor.fetchall()
            # len_successfull_payments = length[0][0]
            #print("len_successfull_payments", len_successfull_payments)


            sql_select_Query = (
                "SELECT payout_till FROM payout WHERE merchant_id=%s ORDER BY created DESC LIMIT 1 ")
            cursor.execute(sql_select_Query, (merchant_id))
            payout_till = cursor.fetchall()
            # print("aaaaaaaa",payout_till)

            
            if payout_till:
                sql_select_Query = (
                "SELECT amount , currency,created,refunded_amt FROM charge WHERE merchant_id=%s AND created>%s AND captured=1 ORDER BY created ASC ")
                cursor.execute(sql_select_Query, (merchant_id,float(payout_till[0][0])))
                amt_cur = cursor.fetchall()
                # print("bbbbbb",amt_cur)
            else:
                sql_select_Query = (
                    "SELECT amount , currency,created,refunded_amt FROM charge WHERE merchant_id=%s ORDER BY created ASC ")
                cursor.execute(sql_select_Query, (merchant_id))
                amt_cur = cursor.fetchall()
                # print("cccccc",amt_cur)
            # print("amt_cur =",amt_cur,type(amt_cur),len(amt_cur))
            sql_select_Query = ("SELECT currency FROM merchant_account WHERE merchant_id=%s and Role='owner'")
            cursor.execute(sql_select_Query, (merchant_id))
            payCurrency = cursor.fetchall()
            # print("dddddddddd",payCurrency)
            if amt_cur:
                total = 0
                for j in range(len(amt_cur)):
                    # print("nobodyyyyy")
                    # print(str(amt_cur[j][1]), str(payCurrency[0][0]))
                    try:
                        refund = int(amt_cur[j][3])

                    except:
                        refund =0
                        # print("yessssssss",refund)
                    
                    try:
                        unit = currency_convertor(str(amt_cur[j][1]), str(payCurrency[0][0]))
                        # print("eeeeeeee",unit)
                    except:
                        unit=0
                        # print("jaooooooo",unit)
                    total = total + float(unit) * float(amt_cur[j][0])- int(refund)
                    
                    # print("payout_till1.2=",payout_till,type(payout_till),amt_cur[j][2],type(amt_cur[j][2]))

                # print("payout_till21=",payout_till)
                fee = (total * 2) / 100
                total=total-fee
            else:
                total=0


            if payCurrency:
                result = {"customer_created":len_customer_created,
                            "successfull_payments":len_successfull_payments,
                            "chargebacks":len_chargebacks,
                            "subscriptions":len_subscriptions,
                            "Amount":total,
                            "currency":payCurrency[0][0]}

                response = {"status": "success", "code": 200,
                            "data": result,
                            "message": "dashboard data"}

                self.write(response)
            else:
                result = {"customer_created":len_customer_created,
                            "successfull_payments":len_successfull_payments,
                            "chargebacks":len_chargebacks,
                            "subscriptions":len_subscriptions,
                            "Amount":total,
                            "currency":"Undefined"}

                response = {"status": "success", "code": 200,
                            "data": result,
                            "message": "dashboard data"}

                self.write(response)



        else:
            response = {
                "status": "error",
                "code": 400,
                "data": "null",
                "message": "error",
            }

            raise tornado.web.Finish(response)


@jwtauth
class d_graph(BaseHandler):

    def get(self):
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))

        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id = m_id
            else:
                pass

        if merchant_id:
            connection, cursor = db_connect()
            todaydate=datetime.datetime.now()
            # #print(todaydate.date()-timedelta(days=15))
            result=[]
            result1=[]
            for i in range(15):
                date=todaydate.date()+timedelta(days=i)-timedelta(days=i)
                date1 = todaydate.date()+timedelta(days=i) - timedelta(days=i+1)
                data=str(date)
                data1 = str(date1)
                # #print((data[0:4]))
                d1 = datetime.datetime(int(data[0:4]),int(data[5:7]), int(data[-2:]))
                d2 = datetime.datetime(int(data1[0:4]), int(data1[5:7]), int(data1[-2:]))
                unixtime = time.mktime(d1.timetuple())
                unixtime1 = time.mktime(d2.timetuple())
                # #print(d1,type(d1))
                #print(unixtime,unixtime1)
                date=datetime.datetime.fromtimestamp(unixtime1).strftime('%Y-%m-%d')
                
                sql_length_query = ("SELECT COUNT(*) FROM customers WHERE merchant_id=cast(%s as char) AND created BETWEEN %s AND %s")
                cursor.execute(sql_length_query, (m_id,unixtime1,unixtime))
                length = cursor.fetchall()
                data={"date":str(date),"cus_count":str(length[0][0])}
                result.append(data)
                sql_length_query = ("SELECT COUNT(*) FROM charge WHERE merchant_id=cast(%s as char) AND created BETWEEN %s AND %s")
                cursor.execute(sql_length_query, (m_id,unixtime1,unixtime))
                length = cursor.fetchall()
                data1={"date":str(date),"charge_count":str(length[0][0])}
                result1.append(data1)
            #print(result)
            response = {"status": "success", "code": 200,
                        "data": result,
                        "data1": result1,
                        "message": "dashboard graph"}
            self.write(response)
                