import pymysql
HOST='localhost'
user='techkopra'
paswd='techkopra123'
db='Payment_gateway1'
connection = pymysql.connect(host=HOST, user=user, password=paswd, db=db)
cursor = connection.cursor()
sql_select_Query = "SELECT public_key,secret_key FROM merchant_account WHERE username='DEV'"

cursor.execute(sql_select_Query, )
records = cursor.fetchall()
public=records[0][0]
private=records[0][1]
#print(public, private)