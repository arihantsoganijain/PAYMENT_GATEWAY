import pymysql

HOST='localhost'
user='techkopra'
paswd='techkopra123'
db='Payment_gateway1'



def db_connect():
    connection = pymysql.connect(host=HOST, user=user, password=paswd, db=db)
    cursor = connection.cursor()
    return connection,cursor


def sql_connect():
    connection = pymysql.connect(host=HOST, user=user, password=paswd)
    cursor = connection.cursor()
    return connection,cursor