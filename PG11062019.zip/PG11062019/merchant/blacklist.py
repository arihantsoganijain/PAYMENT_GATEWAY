import tornado.web
import tornado
import tornado.ioloop
import pyaes
import time
import uuid
import pymysql
import json
from remove_tags import *
import hashlib
from auth import *
from cross_origin import *
from db import *


@jwtauth
class merchant_blacklist(BaseHandler):
    def post(self):
        ruleType = remove_tag(self.get_argument('ruleType'))
        fingerprint = remove_tag(self.get_argument('fingerprint',False))
        cardNumber = remove_tag(self.get_argument('cardNumber',False))
        ipAddress = remove_tag(self.get_argument('ipAddress',False))
        ipCountry = remove_tag(self.get_argument('ipCountry',False))
        metadataKey = remove_tag(self.get_argument('metadataKey',False))
        metadataValue = remove_tag(self.get_argument('metadataValue',False))
        email = remove_tag(self.get_argument('email',False))
        userAgent = remove_tag(self.get_argument('userAgent',False))
        acceptLanguage = remove_tag(self.get_argument('acceptLanguage',False))
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))

        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id = m_id
                user_id=token_decode['userid']
            else:
                pass

        if merchant_id:
            connection, cursor = db_connect()
            select_role='SELECT Role FROM merchant_account WHERE username=cast(%s as char) AND merchant_id=cast(%s as char)'
            cursor.execute(select_role, (user_id,merchant_id))
            Role_check = cursor.fetchall()
            #print(Role_check[0][0])
            alwd_role=['administrator','editor','owner']
            if Role_check[0][0] in alwd_role:
                pass
            else:
                response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "Permission Denied",}
                raise tornado.web.Finish(response)

            if ruleType:

                #print(ruleType,fingerprint)

                black_id="blr_"+str(uuid.uuid1())
                created=time.time()

                #print("database connected")

                fingerprint_record = "0"
                cardNumber_record = "0"
                ipAddress_record = "0"
                ipCountry_record = "0"
                metadataKey_record = "0"
                email_record = "0"
                userAgent_record = "0"
                acceptLanguage_record = "0"
                sql_credit = "INSERT INTO blacklist(black_id , created , objectType ,ruleType , fingerprint ,ipAddress , ipCountry , metadataKey , metadataValue , email , userAgent , acceptLanguage,merchant_id ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"

                if ruleType == 'fingerprint':
                    sql_blacklist = "SELECT fingerprint FROM blacklist WHERE fingerprint=cast(%s as char) AND merchant_id=cast(%s as char)"
                    cursor.execute(sql_blacklist,(fingerprint,merchant_id))
                    fingerprint_blacklist=cursor.fetchall()
                    #print("_____________________------------",fingerprint_blacklist)
                    if fingerprint_blacklist==():
                    ##
                        sql_card = "SELECT fingerprint FROM cards WHERE fingerprint=cast(%s as char) AND merchant_id=cast(%s as char)"
                        cursor.execute(sql_card,(fingerprint,merchant_id))
                        fingerprint_record=cursor.fetchall()
                        connection.commit()
                        if fingerprint_record:
                            cursor.execute(sql_credit, (str(black_id), float(created), "blacklistRule", str(ruleType), str(fingerprint_record[0][0]),
                            str(ipAddress_record), str(ipCountry_record), str(metadataKey_record),str(metadataKey_record),(email_record), str(userAgent_record), str(acceptLanguage_record),merchant_id))
                            connection.commit()
                        else:
                            response={
                                        "status": "error",
                                        "code": 404,
                                        "data": "",
                                        "message": "fingerprint not found"
                                    }
                            raise tornado.web.Finish(response)
                    else:
                        response = {
                            "status": "error",
                            "code": 404,
                            "data": "null",
                            "message": "fingerprint already blacklisted",
                        }
                        raise tornado.web.Finish(response)

                if ruleType == 'cardNumber':
                    fingerprint = hashlib.sha224(cardNumber.encode()).hexdigest()
                    sql_blacklist = "SELECT fingerprint FROM blacklist WHERE fingerprint=cast(%s as char) AND merchant_id=cast(%s as char)"
                    cursor.execute(sql_blacklist,(cardNumber,merchant_id))
                    fingerprint_blacklist=cursor.fetchall()
                    #print("_____________________------------",fingerprint_blacklist)
                    if fingerprint_blacklist==():
                    ##
                        sql_card = "SELECT fingerprint FROM cards WHERE fingerprint=cast(%s as char) AND merchant_id=cast(%s as char)"
                        cursor.execute(sql_card, (fingerprint,merchant_id))
                        cardNumber_record = cursor.fetchall()

                        connection.commit()
                        if cardNumber_record:
                            cursor.execute(sql_credit, (
                            str(black_id), float(created), "blacklistRule", str(ruleType), str(fingerprint),
                            str(ipAddress_record), str(ipCountry_record), str(metadataKey_record), str(metadataKey_record),
                            (email_record), str(userAgent_record), str(acceptLanguage_record),merchant_id))
                            connection.commit()
                        else:
                            response = {
                                "status": "error",
                                "code": 404,
                                "data": "",
                                "message": "cardNumber not found",
                            }
                            raise tornado.web.Finish(response)
                    else:
                        response = {
                            "status": "error",
                            "code": 404,
                            "data": "null",
                            "message": "cardnumber already blacklisted",
                        }
                        raise tornado.web.Finish(response)



                if ruleType == 'ipAddress':
                    sql_blacklist = "SELECT ipAddress FROM blacklist WHERE ipAddress=cast(%s as char) AND merchant_id=cast(%s as char)"
                    cursor.execute(sql_blacklist,(ipAddress,merchant_id))
                    fingerprint_blacklist=cursor.fetchall()
                    #print("_____________________------------",fingerprint_blacklist)
                    if fingerprint_blacklist==():


                        sql_card = "SELECT ipAddress FROM cards WHERE ipAddress=%s AND merchant_id=cast(%s as char)"
                        cursor.execute(sql_card,(ipAddress,merchant_id))
                        ipAddress_record=cursor.fetchall()
                        connection.commit()
                        #print("carddddd")
                        if ipAddress_record:
                            cursor.execute(sql_credit, (
                            str(black_id), float(created), "blacklistRule", str(ruleType), str(fingerprint_record),
                            str(ipAddress_record[0][0]), str(ipCountry_record), str(metadataKey_record), str(metadataKey_record),
                            (email_record), str(userAgent_record), str(acceptLanguage_record),merchant_id))
                            connection.commit()
                        else:
                            response = {
                                "status": "error",
                                "code": 404,
                                "data": "",
                                "message": "ipAddress not found",
                            }
                            raise tornado.web.Finish(response)
                    else:
                        response = {
                            "status": "error",
                            "code": 404,
                            "data": "null",
                            "message": "ipAddress already blacklisted",
                        }
                        raise tornado.web.Finish(response)




                if ruleType == 'ipCountry':
                    ipCountry_record=ipCountry
                    sql_blacklist = "SELECT ipCountry FROM blacklist WHERE ipCountry=cast(%s as char) AND merchant_id=cast(%s as char)"
                    cursor.execute(sql_blacklist,(ipCountry,merchant_id))
                    fingerprint_blacklist=cursor.fetchall()
                    #print("_____________________------------",fingerprint_blacklist)
                    if fingerprint_blacklist==():


                        if ipCountry_record:
                            cursor.execute(sql_credit, (
                            str(black_id), float(created), "blacklistRule", str(ruleType), str(fingerprint_record),
                            str(ipAddress_record), str(ipCountry_record), str(metadataKey_record), str(metadataKey_record),
                            (email_record), str(userAgent_record), str(acceptLanguage_record),merchant_id))
                            connection.commit()
                        else:
                            response = {
                                "status": "error",
                                "code": 404,
                                "data": "",
                                "message": "ipCountry not found",
                            }
                            raise tornado.web.Finish(response)

                    else:
                        response = {
                            "status": "error",
                            "code": 404,
                            "data": "null",
                            "message": "ipCountry already blacklisted",
                        }
                        raise tornado.web.Finish(response)





                if ruleType == 'metadataKey':

                    metadataKey_record = metadataKey
                    sql_blacklist = "SELECT metadataKey FROM blacklist WHERE metadataKey=cast(%s as char) AND merchant_id=cast(%s as char) "
                    cursor.execute(sql_blacklist,(metadataKey,merchant_id))
                    fingerprint_blacklist=cursor.fetchall()
                    #print("_____________________------------",fingerprint_blacklist)
                    if fingerprint_blacklist==():

                        if metadataKey_record:
                            cursor.execute(sql_credit, (
                            str(black_id), float(created), "blacklistRule", str(ruleType), str(fingerprint_record),
                            str(ipAddress_record), str(ipCountry_record), str(metadataKey_record), str(metadataKey_record),
                            (email_record), str(userAgent_record), str(acceptLanguage_record),merchant_id))
                            connection.commit()
                        else:
                            response = {
                                "status": "error",
                                "code": 404,
                                "data": "",
                                "message": "metadataKey not found",
                            }
                            raise tornado.web.Finish(response)
                    else:
                        response = {
                            "status": "error",
                            "code": 404,
                            "data": "null",
                            "message": "metadataKey already blacklisted",
                        }
                        raise tornado.web.Finish(response)


                if ruleType == 'metadataValue':
                    metadataKey_record = metadataValue
                    sql_blacklist = "SELECT metadataValue FROM blacklist WHERE metadataValue=cast(%s as char) AND merchant_id=cast(%s as char)"
                    cursor.execute(sql_blacklist,(metadataValue,merchant_id))
                    fingerprint_blacklist=cursor.fetchall()
                    #print("_____________________------------",fingerprint_blacklist)

                    if fingerprint_blacklist==():


                        if metadataKey_record:
                            cursor.execute(sql_credit, (
                            str(black_id), float(created), "blacklistRule", str(ruleType), str(fingerprint_record),
                            str(ipAddress_record), str(ipCountry_record), str(metadataKey_record), str(metadataKey_record),
                            (email_record), str(userAgent_record), str(acceptLanguage_record),merchant_id))
                            connection.commit()
                        else:
                            response = {
                                "status": "error",
                                "code": 404,
                                "data": "",
                                "message": "metadataValue not found",
                            }
                            raise tornado.web.Finish(response)
                    else:
                        response = {
                            "status": "error",
                            "code": 404,
                            "data": "null",
                            "message": "metadataValue already blacklisted",
                        }
                        raise tornado.web.Finish(response)

                if ruleType == 'email':
                    sql_blacklist = "SELECT email FROM blacklist WHERE email=cast(%s as char) AND merchant_id=cast(%s as char)"
                    cursor.execute(sql_blacklist,(email,merchant_id))
                    fingerprint_blacklist=cursor.fetchall()
                    #print("_____________________------------",fingerprint_blacklist)

                    if fingerprint_blacklist==():
                        sql_card = "SELECT email FROM cards WHERE email=cast(%s as char) AND merchant_id=cast(%s as char) "
                        cursor.execute(sql_card, (email,merchant_id))
                        email_record = cursor.fetchall()
                        connection.commit()
                        if email_record:
                            cursor.execute(sql_credit, (
                            str(black_id), float(created), "blacklistRule", str(ruleType), str(fingerprint_record),
                            str(ipAddress_record), str(ipCountry_record), str(metadataKey_record), str(metadataKey_record),
                            (email_record[0][0]), str(userAgent_record), str(acceptLanguage_record),merchant_id))
                            connection.commit()
                        elif email_record==():
                            sql_card = "SELECT email FROM customers WHERE email=cast(%s as char) AND merchant_id=cast(%s as char)"
                            cursor.execute(sql_card, (email,merchant_id))
                            email_record = cursor.fetchall()
                            if email_record:
                                cursor.execute(sql_credit, (
                                str(black_id), float(created), "blacklistRule", str(ruleType), str(fingerprint_record),
                                str(ipAddress_record), str(ipCountry_record), str(metadataKey_record), str(metadataKey_record),
                                (email_record[0][0]), str(userAgent_record), str(acceptLanguage_record),merchant_id))
                                connection.commit()

                            else:
                                response = {
                                    "status": "error",
                                    "code": 404,
                                    "data": "",
                                    "message": "email not found",
                                }
                                raise tornado.web.Finish(response)
                    else:
                        response = {
                            "status": "error",
                            "code": 404,
                            "data": "null",
                            "message": "email already blacklisted",
                        }
                        raise tornado.web.Finish(response)
                    


                if ruleType == 'userAgent':
                    sql_blacklist = "SELECT userAgent FROM blacklist WHERE userAgent=cast(%s as char) AND merchant_id=cast(%s as char)"
                    cursor.execute(sql_blacklist,(userAgent,merchant_id))
                    fingerprint_blacklist=cursor.fetchall()
                    #print("_____________________------------",fingerprint_blacklist)
                    if fingerprint_blacklist==():


                        sql_card = "SELECT userAgent FROM cards WHERE userAgent=cast(%s as char) AND merchant_id=cast(%s as char)"
                        cursor.execute(sql_card, (userAgent,merchant_id))
                        userAgent_record = cursor.fetchall()
                        if userAgent_record:
                            cursor.execute(sql_credit, (
                            str(black_id), float(created), "blacklistRule", str(ruleType), str(fingerprint_record),
                            str(ipAddress_record), str(ipCountry_record), str(metadataKey_record), str(metadataKey_record),
                            (email_record), str(userAgent_record[0][0]), str(acceptLanguage_record),merchant_id))
                            connection.commit()

                        else:
                            response = {
                                "status": "error",
                                "code": 404,
                                "data": "",
                                "message": "userAgent not found",
                            }
                            raise tornado.web.Finish(response)

                    else:
                        response = {
                            "status": "error",
                            "code": 404,
                            "data": "null",
                            "message": "userAgent already blacklisted",
                        }
                        raise tornado.web.Finish(response)


                if ruleType == 'acceptLanguage':

                    sql_blacklist = "SELECT acceptLanguage FROM blacklist WHERE acceptLanguage=cast(%s as char) AND merchant_id=cast(%s as char)"
                    cursor.execute(sql_blacklist,(acceptLanguage,merchant_id))
                    fingerprint_blacklist=cursor.fetchall()
                    #print("_____________________------------",fingerprint_blacklist)
                    if fingerprint_blacklist==():

                        sql_card = "SELECT acceptLanguage FROM cards WHERE acceptLanguage=cast(%s as char) AND merchant_id=cast(%s as char)"
                        cursor.execute(sql_card, (acceptLanguage,merchant_id))
                        acceptLanguage_record = cursor.fetchall()
                        if acceptLanguage_record:
                            cursor.execute(sql_credit, (
                            str(black_id), float(created), "blacklistRule", str(ruleType), str(fingerprint_record),
                            str(ipAddress_record), str(ipCountry_record), str(metadataKey_record), str(metadataKey_record),
                            (email_record), str(userAgent_record), str(acceptLanguage_record[0][0]),merchant_id))
                            connection.commit()

                        else:
                            response = {
                                "status": "error",
                                "code": 404,
                                "data": "",
                                "message": "acceptLanguage not found",
                            }
                            raise tornado.web.Finish(response)

                    else:
                        response = {
                            "status": "error",
                            "code": 404,
                            "data": "null",
                            "message": "acceptLanguage already blacklisted",
                        }
                        raise tornado.web.Finish(response)



                sql_select_Query = "SELECT * FROM blacklist WHERE black_id=cast(%s as char) AND merchant_id=cast(%s as char)"

                cursor.execute(sql_select_Query, (black_id,merchant_id))

                records = cursor.fetchall()
                connection.commit()
                #print(records)
                if records:
                    result={
                    "id" : records[0][0],
                    "created" :  str(records[0][1]),
                    "objectType" : records[0][2],
                    "ruleType" : records[0][3],
                    "fingerprint" : records[0][4],
                    "email":records[0][9],
                    "ipAddress" :records[0][5],
                    "ipCountry":records[0][6],
                    "metadataKey": records[0][7],
                    "metadataValue": records[0][8],
                    "userAgent": records[0][10],
                    "acceptLanguage":records[0][11],}


                    response={"status": "success","code": 200,
                    "data": result,
                    "message": "Sucessfully added to Blacklist"}
                    #print("response---------------------------------",response)
                    self.write(response)



                else:
                    response = {
                    "status": "error",
                    "code": 400,
                    "data": "",
                    "message": "id not exist",}
                    raise tornado.web.Finish(response)

            else:
                response = {
                    "status": "error",
                    "code": 400,
                    "data": "",
                    "message": "BAd REquest",
                }
                raise tornado.web.Finish(response)
        else:

            response = {
                "status": "error",
                "code": 403,
                "data": "",
                "message": "Access Denied",
            }

            raise tornado.web.Finish(response)

    def get(self):

        blacklistRuleId=regex(remove_tag(self.get_argument('blacklistRuleId')))
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))

        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id = m_id
            else:
                pass

        if merchant_id:

            if blacklistRuleId:

                connection,cursor=db_connect()

                sql_select_Query = "SELECT * FROM blacklist WHERE black_id=cast(%s as char) AND merchant_id=cast(%s as char)"

                cursor.execute(sql_select_Query, (blacklistRuleId,merchant_id))

                records = cursor.fetchall()
                connection.commit()

                #print(records)
                if records:
                    result = {
                        "id": records[0][0],
                        "created": str(records[0][1]),
                        "objectType": records[0][2],
                        "ruleType": records[0][3],
                        "fingerprint": records[0][4],
                        "email": records[0][9],
                        "ipAddress": records[0][5],
                        "ipCountry": records[0][6],
                        "metadataKey": records[0][7],
                        "metadataValue": records[0][8],
                        "userAgent": records[0][10],
                        "acceptLanguage": records[0][11], }

                    response={"status": "success","code": 200,
                    "data": result,
                    "message": ""}
                    self.write(response)
                else:
                    response = {
                        "status": "error",
                        "code": 400,
                        "data": "",
                        "message": "BAd REquest",
                    }
                    raise tornado.web.Finish(response)
            else:
                response = {
                    "status": "error",
                    "code": 400,
                    "data": "",
                    "message": "BAd REquest",
                }
                raise tornado.web.Finish(response)
        else:

            response = {
                "status": "error",
                "code": 403,
                "data": "",
                "message": "Access Denied",
            }

            raise tornado.web.Finish(response)

@jwtauth
class merchant_delete_blacklist(BaseHandler):

    def post(self):
        blacklistRuleId = regex(remove_tag(self.get_argument('blacklistRuleId')))
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))

        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id = m_id
                user_id=token_decode['userid']
            else:
                pass

        if merchant_id:
            connection, cursor = db_connect()
            select_role='SELECT Role FROM merchant_account WHERE username=cast(%s as char) AND merchant_id=cast(%s as char)'
            cursor.execute(select_role, (user_id,merchant_id))
            Role_check = cursor.fetchall()
            #print(Role_check[0][0])
            alwd_role=['administrator','editor','owner']
            if Role_check[0][0] in alwd_role:
                pass
            else:
                response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "Permission Denied",}
                raise tornado.web.Finish(response)
            if blacklistRuleId:
                connection, cursor = db_connect()

                sql_select_Query = "SELECT * FROM blacklist WHERE black_id=cast(%s as char) AND merchant_id=cast(%s as char)"

                cursor.execute(sql_select_Query, (blacklistRuleId,merchant_id))

                records = cursor.fetchall()

                if records:
                    sql_credit = "INSERT INTO deleted_blacklist(black_id , created , objectType ,ruleType , fingerprint ,ipAddress , ipCountry , metadataKey , metadataValue , email , userAgent , acceptLanguage,merchant_id ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                    cursor.execute(sql_credit, (
                        str(records[0][0]), float(records[0][1]), records[0][2], str(records[0][3]), records[0][4], records[0][5],
                        records[0][6], records[0][7], records[0][8], records[0][9], records[0][10],
                        records[0][11],merchant_id))
                    connection.commit()
                    sql_select_Query = "DELETE FROM blacklist WHERE black_id=cast(%s as char) AND merchant_id=cast(%s as char)"

                    cursor.execute(sql_select_Query, (blacklistRuleId,merchant_id))
                    connection.commit()

                    result = {
                        "id": blacklistRuleId, }

                    response={"status": "success","code": 200,
                    "data": result,
                    "message": "blacklist deleted successfully"}
                    self.write(response)
                else:
                    response = {
                        "status": "error",
                        "code": 404,
                        "data": "",
                        "message": "Id doesn't exist",
                    }
                    raise tornado.web.Finish(response)
            else:
                response = {
                    "status": "error",
                    "code": 400,
                    "data": "",
                    "message": "BAd REquest",
                }
                raise tornado.web.Finish(response)

        else:

            response = {
                "status": "error",
                "code": 403,
                "data": "",
                "message": "Access Denied",
            }

            raise tornado.web.Finish(response)


@jwtauth
class merchant_list_Blacklist_Rules(BaseHandler):
    def get(self):
        created = remove_tag(self.get_argument('created', False))
        operation = remove_tag(self.get_argument('operation', False))
        deleted = remove_tag(self.get_argument('deleted', False))
        limit = remove_tag(self.get_argument('limit', False))
        startingAfterId = regex(remove_tag(self.get_argument('startingAfterId', False)))
        endingBeforeId = regex(remove_tag(self.get_argument('endingBeforeId', False)))
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))

        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id = m_id
            else:
                pass

        if merchant_id:

            connection, cursor = db_connect()


            sql_length_query = ("SELECT COUNT(*) FROM blacklist WHERE merchant_id=cast(%s as char)")
            cursor.execute(sql_length_query,(merchant_id))
            length = cursor.fetchall()

            len_records1=length[0][0]

            if limit == False:
                limit = 10
            elif int(limit) > 100:
                limit = 100

            if deleted == False or deleted == "0":

                if operation == "lt" or operation == "lte" or operation == "gt" or operation == "gte" and created:

                    if operation == "lt":
                        sql_select_Query = ("SELECT * FROM blacklist WHERE created < %s AND merchant_id=cast(%s as char)  ORDER BY created DESC LIMIT %s ")
                    elif operation == "lte":
                        sql_select_Query = ("SELECT * FROM blacklist WHERE created <= %s AND merchant_id=cast(%s as char) ORDER BY created DESC LIMIT %s")
                    elif operation == "gt":
                        sql_select_Query = ("SELECT * FROM blacklist WHERE created > %s AND merchant_id=cast(%s as char) ORDER BY created DESC LIMIT %s")
                    elif operation == "gte":
                        sql_select_Query = ("SELECT * FROM blacklist WHERE created >= %s AND merchant_id=cast(%s as char) ORDER BY created DESC LIMIT %s")

                    cursor.execute(sql_select_Query, (float(created),merchant_id, int(limit)))
                    records = cursor.fetchall()
                    #print("records",records)
                    connection.commit()
                    # len_records = len(records)
                    limit = len(records)
                    if len(records) == int(limit):
                        # card_ID = []
                        # for i in range(limit):
                        #     var = records[i][7]
                        #     #print(var)
                        #     if var.startswith("tok_"):
                        #         connection = pymysql.connect(host='localhost', user='root', password='', db='token')
                        #         cursor = connection.cursor()
                        #         sql_select_Query = ("SELECT card_id FROM token WHERE id=%s")
                        #
                        #         cursor.execute(sql_select_Query, records[i][7])
                        #         card_records = cursor.fetchall()
                        #         card_ID.append(card_records)
                        #     elif var.startswith("card_"):
                        #         card_ID.append(records[i][7])
                        #     else:
                        #         card_ID.append("")
                        #
                        # #print("cardid", card_ID)
                        # card_data = []
                        # for i in range(len(records)):
                        #     connection = pymysql.connect(host='localhost', user='root', password='', db='card')
                        #     cursor = connection.cursor()
                        #     sql_select_Query = ("SELECT * FROM cards WHERE card_id= %s ")
                        #
                        #     cursor.execute(sql_select_Query, (card_ID[i]))
                        #     data = cursor.fetchall()
                        #     card_data.append(data)
                        # #print("card_data", card_data)
                        result = []
                        for i in range(int(limit)):
                            if records[i] != ():
                                # rules=records[i][3]
                                # #print(rules[1:-1],rules)
                                # sql_select_Query = (f"SELECT blacklist.{rules} FROM blacklist WHERE black_id=cast(%s as char) AND merchant_id=cast(%s as char) ")
                                # cursor.execute(sql_select_Query, (records[i][0],merchant_id))
                                # rule = cursor.fetchall()
                                for j in range(4,11):
                                    #print("#####################################",records[i][j],type(records[i][j]))
                                    if records[i][j]!='0':
                                        rule=records[i][j]
                                data = {
                                    "id": records[i][0],
                                    "created":  str(records[i][1]),
                                    "objectType": records[i][2],
                                    "ruleType": records[i][3],
                                    "rules": rule, }
                                result.append(data)

                        response = {"status": "success", "code": 200,
                                    "data": result,
                                    "data_length": len_records1,
                                    "message": ""}
                        self.write(response)
                    else:
                        response = {
                            "status": "error",
                            "code": 404,
                            "data": "",
                            "message": "data not available",
                        }
                        raise tornado.web.Finish(response)

                # if customerId and operation==False:
                #     try:
                #         connection = pymysql.connect(host='localhost', user='root', password='', db='blacklist')
                #         cursor = connection.cursor()
                #         sql_select_Query = ("SELECT * FROM blacklist WHERE customerId = %s ORDER BY created DESC LIMIT %s ")
                #         cursor.execute(sql_select_Query, (customerId, int(limit)))
                #         records = cursor.fetchall()
                #         #print(records)
                #         result= []
                #         for i in range(len(records)):
                #             data = {
                #                   "id" : records[0][0],
                #                   "created" : records[0][1],
                #                   "objectType" : records[0][2],
                #                   "amount" : records[0][3],
                #                   "currency" : records[0][4],
                #                   "interval" : records[0][5],
                #                   "intervalCount" : records[0][6],
                #                   "name" : records[0][8],
                #                   "trialPeriodDays" : records[0][9]
                #                 }
                #             result.append(data)
                #
                #         self.write(json.dumps(result))
                #     except:
                #         self.write("Customer not exist")

                if startingAfterId:
                    sql_select_Query = ("SELECT created FROM blacklist WHERE black_id = cast(%s as char) AND merchant_id=cast(%s as char)")
                    cursor.execute(sql_select_Query, (startingAfterId,merchant_id))
                    record = cursor.fetchall()
                    sql_select_Query = ("SELECT * FROM blacklist WHERE created>= %s  AND merchant_id=cast(%s as char) ORDER BY created ASC LIMIT 10 ")
                    cursor.execute(sql_select_Query, (record,merchant_id))
                    records = cursor.fetchall()
                    #print(records)
                    results = []
                    for i in range(len(records)):
                        for j in range(4,11):
                            #print("#####################################",records[i][j],type(records[i][j]))
                            if records[i][j]!='0':
                                rule=records[i][j]
                        data = {
                            "id": records[i][0],
                            "created":  str(records[i][1]),
                            "objectType": records[i][2],
                            "ruleType": records[i][3],
                            "rules": rule, }
                        results.append(data)
                    results = results[::-1]

                    response = {"status": "success", "code": 200,
                                "data": results,
                                "data_length": len_records1,
                                "message": ""}
                    self.write(response)

                if endingBeforeId:

                    sql_select_Query = ("SELECT created FROM blacklist WHERE black_id = cast(%s as char) AND merchant_id=cast(%s as char)")
                    cursor.execute(sql_select_Query, (endingBeforeId,merchant_id))
                    record = cursor.fetchall()
                    sql_select_Query = ("SELECT * FROM blacklist WHERE created<= %s AND merchant_id=cast(%s as char) ORDER BY created DESC LIMIT 10 ")
                    cursor.execute(sql_select_Query, (record,merchant_id))
                    records = cursor.fetchall()
                    #print(records)
                    results = []
                    for i in range(len(records)):
                        for i in range(len(records)):
                            for j in range(4,11):
                                #print("#####################################",records[i][j],type(records[i][j]))
                                if records[i][j]!='0':
                                    rule=records[i][j]
                        data = {
                            "id": records[i][0],
                            "created":  str(records[i][1]),
                            "objectType": records[i][2],
                            "ruleType": records[i][3],
                            "rules": rule }
                        result.append(data)

                    response = {"status": "success", "code": 200,
                                "data": results,
                                "data_length": len_records1,
                                "message": ""}
                    self.write(response)

            if deleted:
                sql_length_query = ("SELECT COUNT(*) FROM blacklist WHERE merchant_id=cast(%s as char)")
                cursor.execute(sql_length_query,(merchant_id))
                length = cursor.fetchall()

                len_records1=length[0][0]
                if operation == "lt" or operation == "lte" or operation == "gt" or operation == "gte" and created:

                    if operation == "lt":
                        sql_select_Query = (
                            "SELECT * FROM deleted_blacklist WHERE created < %s AND merchant_id=cast(%s as char) ORDER BY created DESC LIMIT %s")
                    elif operation == "lte":
                        sql_select_Query = (
                            "SELECT * FROM deleted_blacklist WHERE created <= %s AND merchant_id=cast(%s as char) ORDER BY created DESC LIMIT %s")
                    elif operation == "gt":
                        sql_select_Query = (
                            "SELECT * FROM deleted_blacklist WHERE created > %s AND merchant_id=cast(%s as char) ORDER BY created DESC LIMIT %s")
                    elif operation == "gte":
                        sql_select_Query = (
                            "SELECT * FROM deleted_blacklist WHERE created <= %s AND merchant_id=cast(%s as char) ORDER BY created DESC LIMIT %s")

                    cursor.execute(sql_select_Query, (float(created),merchant_id, int(limit)))
                    records = cursor.fetchall()
                    #print(records)
                    connection.commit()

                    if len(records) == int(limit):
                        # card_ID = []
                        # for i in range(limit):
                        #     var = records[i][7]
                        #     #print(var)
                        #     if var.startswith("tok_"):
                        #         connection = pymysql.connect(host='localhost', user='root', password='', db='token')
                        #         cursor = connection.cursor()
                        #         sql_select_Query = ("SELECT card_id FROM token WHERE id=%s")
                        #
                        #         cursor.execute(sql_select_Query, records[i][7])
                        #         card_records = cursor.fetchall()
                        #         card_ID.append(card_records)
                        #     elif var.startswith("card_"):
                        #         card_ID.append(records[i][7])
                        #     else:
                        #         card_ID.append("")
                        #
                        # #print("cardid", card_ID)
                        # card_data = []
                        # for i in range(len(records)):
                        #     connection = pymysql.connect(host='localhost', user='root', password='', db='card')
                        #     cursor = connection.cursor()
                        #     sql_select_Query = ("SELECT * FROM cards WHERE card_id= %s ")
                        #
                        #     cursor.execute(sql_select_Query, (card_ID[i]))
                        #     data = cursor.fetchall()
                        #     card_data.append(data)
                        # #print("card_data", card_data)
                        result = []
                        for i in range(int(limit)):
                            if records[i] != ():
                                data = {
                                    "id": records[i][0],
                                    "created":  str(records[i][1]),
                                    "objectType": records[i][2],
                                    "ruleType": records[i][3],
                                    "fingerprint": records[i][4], }
                                result.append(data)

                        response = {"status": "success", "code": 200,
                                    "data": result,
                                    "data_length": len_records1,
                                    "message": ""}
                        self.write(response)
                    else:
                        response = {
                            "status": "error",
                            "code": 404,
                            "data": "",
                            "message": "data not available",
                        }
                        raise tornado.web.Finish(response)

                # if customerId and operation==False:
                #     try:
                #         connection = pymysql.connect(host='localhost', user='root', password='', db='blacklist')
                #         cursor = connection.cursor()
                #         sql_select_Query = ("SELECT * FROM blacklist WHERE customerId = %s ORDER BY created DESC LIMIT %s ")
                #         cursor.execute(sql_select_Query, (customerId, int(limit)))
                #         records = cursor.fetchall()
                #         #print(records)
                #         result= []
                #         for i in range(len(records)):
                #             data = {
                #                   "id" : records[0][0],
                #                   "created" : records[0][1],
                #                   "objectType" : records[0][2],
                #                   "amount" : records[0][3],
                #                   "currency" : records[0][4],
                #                   "interval" : records[0][5],
                #                   "intervalCount" : records[0][6],
                #                   "name" : records[0][8],
                #                   "trialPeriodDays" : records[0][9]
                #                 }
                #             result.append(data)
                #
                #         self.write(json.dumps(result))
                #     except:
                #         self.write("Customer not exist")

                if startingAfterId:

                    sql_select_Query = ("SELECT created FROM deleted_blacklist WHERE black_id = cast(%s as char) AND merchant_id=cast(%s as char)")
                    cursor.execute(sql_select_Query, (startingAfterId,merchant_id))
                    record = cursor.fetchall()
                    sql_select_Query = ("SELECT * FROM deleted_blacklist WHERE created>= %s AND merchant_id=cast(%s as char) ORDER BY created ASC LIMIT 10 ")
                    cursor.execute(sql_select_Query, (record,merchant_id))
                    records = cursor.fetchall()
                    #print(records)
                    results = []
                    for i in range(len(records)):
                        result = {
                            "id": records[i][0],
                            "created":  str(records[i][1]),
                            "objectType": records[i][2],
                            "ruleType": records[i][3],
                            "fingerprint": records[i][4], }
                        results.append(result)

                    response = {"status": "success", "code": 200,
                                "data": result,
                                "data_length": len_records1,
                                "message": ""}
                    self.write(response)

                if endingBeforeId:

                    sql_select_Query = ("SELECT created FROM deleted_blacklist WHERE black_id = cast(%s as char) AND merchant_id=cast(%s as char)")
                    cursor.execute(sql_select_Query, (endingBeforeId,merchant_id))
                    record = cursor.fetchall()
                    sql_select_Query = ("SELECT * FROM deleted_blacklist WHERE created<= %s AND merchant_id=cast(%s as char) ORDER BY created DESC LIMIT 10 ")
                    cursor.execute(sql_select_Query, (record,merchant_id))
                    records = cursor.fetchall()
                    #print(records)
                    results = []
                    for i in range(len(records)):
                        result = {
                            "id": records[i][0],
                            "created":  str(records[i][1]),
                            "objectType": records[i][2],
                            "ruleType": records[i][3],
                            "fingerprint": records[i][4], }
                        results.append(result)

                    response = {"status": "success", "code": 200,
                                "data": result,
                                "data_length": len_records1,
                                "message": ""}
                    self.write(response)
        else:

            response = {
                "status": "error",
                "code": 403,
                "data": "",
                "message": "Access Denied",
            }

            raise tornado.web.Finish(response)
@jwtauth
class merchant_blacklist_filter(BaseHandler):
    def post(self):
        ruleType = remove_tag(self.get_argument('ruleType'))
        fingerprint = remove_tag(self.get_argument('fingerprint',False))
        ipAddress = remove_tag(self.get_argument('ipAddress',False))
        ipCountry = remove_tag(self.get_argument('ipCountry',False))
        metadataKey = remove_tag(self.get_argument('metadataKey',False))
        metadataValue = remove_tag(self.get_argument('metadataValue',False))
        email = remove_tag(self.get_argument('email',False))
        userAgent = remove_tag(self.get_argument('userAgent',False))
        acceptLanguage = remove_tag(self.get_argument('acceptLanguage',False))
        token = self.request.headers.get('Authorization')
        limit=self.get_argument('limit', False)
        m_id = remove_tag(self.get_argument('m_id'))
        time=self.get_argument('time', False)
        pre_time=self.get_argument('pre_time', False)



        if limit ==False:
            limit=10
        else:
            limit=int(limit)
        
        if limit>100:
            limit=100


        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id = m_id
            else:
                pass

        if merchant_id:
            #print(merchant_id,'merchant_id')
            connection, cursor = db_connect()

            query = f"SELECT * FROM blacklist WHERE created<{time}"
            count_query = f"SELECT COUNT(*) FROM blacklist WHERE created<{time}"
            if pre_time:
                query = f"SELECT * FROM blacklist WHERE created>{time}"

            if ruleType =='fingerprint' :
                if query[-5:] == "WHERE":
                    add = f" fingerprint = '{fingerprint}'"
                else:
                    add = f" AND fingerprint = '{fingerprint}'"

                query = query + add
                count_query=count_query+add
            
            if ruleType =='ipAddress':
                if query[-5:] == "WHERE":
                    add = f" ipAddress = '{ipAddress}'"
                else:
                    add = f" AND ipAddress = '{ipAddress}'"

                query = query + add
                count_query=count_query+add

            if ruleType =='ipCountry':
                if query[-5:] == "WHERE":
                    add = f" ipCountry = '{ipCountry}'"
                else:
                    add = f" AND ipCountry = '{ipCountry}'"
            
                    query = query + add
                    count_query=count_query+add

            if ruleType =='metadataKey':
                if query[-5:] == "WHERE":
                    add = f" metadataKey = '{metadataKey}'"
                else:
                    add = f" AND metadataKey = '{metadataKey}'"
            
                query = query + add
                count_query=count_query+add

            if ruleType =='metadataValue':
                if query[-5:] == "WHERE":
                    add = f" metadataValue = '{metadataValue}'"
                else:
                    add = f" AND metadataValue = '{metadataValue}'"
                query = query + add
                count_query=count_query+add
            
            if ruleType =='email':
                if query[-5:] == "WHERE":
                    add = f" email = '{email}'"
                else:
                    add = f" AND email = '{email}'"
                query = query + add
                count_query=count_query+add
            if ruleType =='userAgent':
                if query[-5:] == "WHERE":
                    add = f" userAgent = '{userAgent}'"
                else:
                    add = f" AND userAgent = '{userAgent}'"
                query = query + add
                count_query=count_query+add
            if ruleType =='acceptLanguage':
                if query[-5:] == "WHERE":
                    add = f" acceptLanguage = '{acceptLanguage}'"
                else:
                    add = f" AND acceptLanguage = '{acceptLanguage}'"
        
                query = query + add
                count_query=count_query+add
            
            if time:
                if query[-5:] == "WHERE":
                    add = f" merchant_id = '{merchant_id}' ORDER BY created DESC LIMIT {limit}"
                    cadd = f" merchant_id = '{merchant_id}'"
                else:
                    add = f" AND merchant_id = '{merchant_id}' ORDER BY created DESC LIMIT {limit}"
                    cadd = f" AND merchant_id = '{merchant_id}'"
            if pre_time:
                if query[-5:] == "WHERE":
                    add = f" merchant_id = '{merchant_id}' ORDER BY created ASC LIMIT {limit}"
                    cadd = f" merchant_id = '{merchant_id}'"

                else:
                    add = f" AND merchant_id = '{merchant_id}' ORDER BY created ASC LIMIT {limit}"
                    cadd = f" AND merchant_id = '{merchant_id}'"
            count_query=count_query+cadd
            query = query + add
            #print("query",query)
            cursor.execute(query)
            records = cursor.fetchall()
            cursor.execute(count_query)
            count = cursor.fetchall()
            if records:
                results=[]
                # for i in range(len(records)):
                #     result = {
                #         "id": records[i][0],
                #         "created": str(records[i][1]),
                #         "objectType": records[i][2],
                #         "ruleType": records[i][3],
                #         "fingerprint": records[i][4],
                #         "email": records[i][9],
                #         "ipAddress": records[i][5],
                #         "ipCountry": records[i][6],
                #         "metadataKey": records[i][7],
                #         "metadataValue": records[i][8],
                #         "userAgent": records[i][10],
                #         "acceptLanguage": records[i][11], }
                #     results.append(result)

                for i in range(len(records)):
                    for j in range(4,11):
                        #print("#####################################",records[i][j],type(records[i][j]))
                        if records[i][j]!='0':
                            rule=records[i][j]
                    data = {
                        "id": records[i][0],
                        "created":  str(records[i][1]),
                        "objectType": records[i][2],
                        "ruleType": records[i][3],
                        "rules": rule, }
                    results.append(data)

                response = {"status": "success","code": 200,
                            "data": results,
                            "data_length":count[0][0],
                            "message": ""}
                self.write(response)
            else:
                response = {
                    "status": "error",
                    "code": 404,
                    "data": "",
                    "message": "data not available",
                }
                raise tornado.web.Finish(response)
        else:

            response = {
                "status": "error",
                "code": 403,
                "data": "",
                "message": "Access Denied",
            }

            raise tornado.web.Finish(response)



