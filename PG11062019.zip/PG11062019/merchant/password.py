import tornado.web
import tornado
import tornado.ioloop
import pyaes
import time
import uuid
import pymysql
import json
from remove_tags import *
from auth import *
from cross_origin import *
from db import *
import hashlib


class BaseHandler1(tornado.web.RequestHandler):

    def set_default_headers(self):
        ##print("setting headers!!!")
        self.set_header("Access-Control-Allow-Origin", "*")
        # self.add_header('Access-Control-Allow-Origin', self.request.headers.get('Origin', '*'))
        self.set_header('Access-Control-Allow-Methods', 'POST, GET')
        # self.add_header('Access-Control-Request-Method', 'GET')
        self.set_header('Access-Control-Allow-Headers', 'Content-Type')
        # self.add_header('Access-Control-Allow-Headers', 'X-Requested-With')
        self.set_header("Access-Control-Allow-Credentials", "false")
        # self.set_header('Access-Control-Max-Age', '86400')

        self.set_header("Access-Control-Allow-Headers", "browser,ipaddress,platform,x-requested-with,access-control-allow-origin,X-PINGOTHER,authorization")
        #print("set headers!!!")

    def post(self):
        self.write('some post')

    def get(self):
        self.write('some get')


def check_login( username, password):
    connection, cursor = db_connect()
    query="SELECT username ,password FROM merchant"
    cursor.execute(query)
    all=cursor.fetchall()

    if username and password:
        for i in all:
            if i[0]==username and i[1]==password:
                return 1
        else:
            return 2
    else:
        return 3
@jwtauth
class pass_change(BaseHandler):

    def post(self):

        old_pass = remove_tag(self.get_argument('old_pass'))
        new_pass=remove_tag(self.get_argument('new_pass'))
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))

        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            #print(token_decode['mAndR'][i],"======================",token_decode)
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id=m_id
                user_id=token_decode['userid']
            else:
                pass

        if merchant_id:
            connection, cursor = db_connect()
            select_role='SELECT Role FROM merchant_account WHERE username=cast(%s as char) AND merchant_id=cast(%s as char)'
            cursor.execute(select_role, (user_id,merchant_id))
            Role_check = cursor.fetchall()
            #print(Role_check[0][0])
            alwd_role=['owner']
            if Role_check[0][0] in alwd_role:
                pass
            else:
                response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "Permission Denied",}
                raise tornado.web.Finish(response)
            old_pass=hashlib.sha224(old_pass.encode()).hexdigest()
            checklogin=check_login(user_id,old_pass)
            if checklogin==1:
                pattern = re.compile("^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$")
                if pattern.match(new_pass):
                    new_pass = hashlib.sha224(new_pass.encode()).hexdigest()
                    pass_update="UPDATE merchant SET password=%s WHERE username=%s"
                    cursor.execute(pass_update, (new_pass,user_id))
                    connection.commit()
                    response = {
                            "status": "success",
                            "code": 200,
                            "data": "",
                            "message": "password changed sucessfully",}
                    #print("response",response)
                    self.write(response)
                else:
                    response = {
                            "status": "error",
                            "code": 400,
                            "data": "",
                            "message": "password must include Minimum eight characters, at least one letter, one number and one special character",}
                    raise tornado.web.Finish(response)
            else:
                response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "Incorrect password",}
                raise tornado.web.Finish(response)

        else:
                response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "permission denied",}
                raise tornado.web.Finish(response)

        


@jwtauth
class acc_name_change(BaseHandler1):

    def post(self):
        account_name = remove_tag(self.get_argument('account_name'))
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))
        #print(account_name,m_id,"$$$$$$$$$$$")
        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            #print(token_decode['mAndR'][i],"======================",token_decode)
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id=m_id
                user_id=token_decode['userid']
            else:
                pass

        if merchant_id:
            connection, cursor = db_connect()
            select_role='SELECT Role FROM merchant_account WHERE merchant_id=cast(%s as char)'
            cursor.execute(select_role, (m_id))
            Role_check = cursor.fetchall()
            #print(Role_check[0][0])
            alwd_role=['owner']
            #print(account_name,m_id,"$$$$$$$$$$$")
            if Role_check[0][0] in alwd_role:
                #print(account_name,m_id,"$$$$$$$$$$$")
                acc_update="UPDATE merchant_account SET account_name=%s WHERE merchant_id=cast(%s as char)"
                cursor.execute(acc_update, (account_name,m_id))
                connection.commit()
                response = {
                        "status": "success",
                        "code": 200,
                        "data": account_name,
                        "message": "account name  changed sucessfully",}
                #print("response",response)
                self.write(response)
            
            else:
                response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "Permission Denied",}
                raise tornado.web.Finish(response)
        else:

            response = {
                "status": "error",
                "code": 403,
                "data": "",
                "message": "Access Denied",
            }

@jwtauth
class currency_change(BaseHandler):

    def post(self):

        currency = remove_tag(self.get_argument('currency'))
        token = self.request.headers.get('Authorization')
        m_id = remove_tag(self.get_argument('m_id'))

        parts = token.split()
        token = parts[1]
        token_decode = jwt.decode(
            token,
            secret_key,
            options=options, algorithm='HS256')
        merchant_id = 0
        for i in range(len(token_decode['mAndR'])):
            #print(token_decode['mAndR'][i],"======================",token_decode)
            if m_id in token_decode['mAndR'][i]['merchant_id']:
                merchant_id=m_id
                user_id=token_decode['userid']
            else:
                pass

        if merchant_id:
            connection, cursor = db_connect()
            select_role='SELECT Role FROM merchant_account WHERE merchant_id=cast(%s as char)'
            cursor.execute(select_role, (m_id))
            Role_check = cursor.fetchall()
            #print(Role_check[0][0])
            alwd_role=['owner']
            if Role_check[0][0] in alwd_role:
                currency_update="UPDATE merchant_account SET currency=%s WHERE merchant_id=cast(%s as char)"
                cursor.execute(currency_update, (currency,m_id))
                connection.commit()
                response = {
                        "status": "success",
                        "code": 200,
                        "data": currency,
                        "message": "currency changed sucessfully",}
                #print("response",response)
                self.write(response)
            
            else:
                response = {
                        "status": "error",
                        "code": 403,
                        "data": "",
                        "message": "Permission Denied",}
                raise tornado.web.Finish(response)
        else:

            response = {
                "status": "error",
                "code": 403,
                "data": "",
                "message": "Access Denied",
            }

        

        
