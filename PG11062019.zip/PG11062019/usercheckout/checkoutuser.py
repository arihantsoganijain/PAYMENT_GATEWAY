import tornado.ioloop
import tornado.web
import os
from db import *
# print("sdrthrthjhrthrtjhrtjtyjtyjtyjwjrtjhrtjhrtjh654jrt4654j6tyj4ty6j4ty")


class Checkout(tornado.web.RequestHandler):
    def post(self):
        mrc = self.get_argument("mrc")
        amount = self.get_argument("amount")
        currency = self.get_argument("currency")
        redirectUrl = self.get_argument("redirectUrl")
        if mrc == "" or amount == "" or currency == "" or redirectUrl== "":
            response = {
                                "status": "error",
                                "code": 404,
                                "data": "null",
                                "message": "somthing is missing !!!",
                            }
            raise tornado.web.Finish(response)
        try:
            print("amount = ",amount,type(amount))
            if isinstance(float(amount), float):
                connection, cursor = db_connect()
                select_role='SELECT * FROM merchant_account WHERE merchant_id=cast(%s as char)'
                cursor.execute(select_role, (mrc))
                Role_check = cursor.fetchall()
                if not  Role_check:
                    response = {
                                        "status": "error",
                                        "code": 404,
                                        "data": "null",
                                        "message": "Marchant not found",
                                    }
                    raise tornado.web.Finish(response)
                self.render("checkout_amalpay.html",amount=amount,currency=currency,mrc=mrc,redirectUrl=redirectUrl)
            else:
                response = {
                            "status": "error",
                            "code": 404,
                            "data": "null",
                            "message": amount,
                        }
                raise tornado.web.Finish(response)
        except:
            response = {
                        "status": "error",
                        "code": 404,
                        "data": "null",
                        "message":"somthing wrong",
                    }
            raise tornado.web.Finish(response)

# settings = dict(
#         static_path=os.path.join(os.path.dirname(__file__), "static")
#     )
# def make_app():
#     return tornado.web.Application([
#         (r"/checkout", Checkout),
#         (r"/(.*)", tornado.web.StaticFileHandler,
#          dict(path=settings['static_path']))
#     ],**settings)

# if __name__ == "__main__":
#     app = make_app()
#     app.listen(8888)
#     tornado.ioloop.IOLoop.current().start()